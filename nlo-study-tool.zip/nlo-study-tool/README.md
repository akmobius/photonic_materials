# Nonlinear Optics Study Tool
### MIT · Fujimoto · 6.634

A self-contained browser-based study tool covering all major nonlinear optics topics.

---

## How to use

1. **Double-click `index.html`** to open it in any browser — no server, no installation needed.
2. For the **Problem Solver** and **Concept Explainer** AI features, you'll need a free [Anthropic API key](https://console.anthropic.com/). Enter it in the field that appears in those tabs.
3. The **Flashcard** tab works offline with no API key — all 35 cards are built in.

---

## Topics covered

| Topic | Cards | AI support |
|---|---|---|
| Wave propagation & dispersion | 5 | Yes |
| Nonlinear susceptibilities (χ², χ³) | 5 | Yes |
| SHG / parametric processes | 5 | Yes |
| Solitons & pulse compression | 5 | Yes |
| Stimulated Raman/Brillouin | 5 | Yes |
| Four-wave mixing | 5 | Yes |
| Quantum nonlinear optics | 5 | Yes |

---

## Features

- **Flashcards** — 35 exam-style Q&A cards, shuffleable, with got-it/missed tracking
- **Problem solver** — paste any problem and get a step-by-step solution from Claude
- **Concept explainer** — ask any NLO question, with quick-access buttons for key topics (Manley-Rowe, SVEA, optical Bloch, squeezing & PDC, density matrix χ, soliton number N, and more)

---

## Getting an API key

1. Go to [console.anthropic.com](https://console.anthropic.com/)
2. Sign up / log in and create a new API key
3. Paste it into the key field in the app (it stays local to your browser tab — never sent anywhere except the Anthropic API)

---

Made with Claude · Good luck on the exam
